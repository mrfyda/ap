package ist.meic.pa;

public class Trace {

    public static void print(Object object) {
        TraceHistory.printTraceSteps(object);
    }

}
