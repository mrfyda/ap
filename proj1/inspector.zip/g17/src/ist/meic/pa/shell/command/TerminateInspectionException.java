package ist.meic.pa.shell.command;

public class TerminateInspectionException extends Exception {
}
