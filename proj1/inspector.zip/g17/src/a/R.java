package a;

public class R {

    public String F(Integer a) {
        return "The Integer is " + a.toString();
    }

    public String f(int a) {
        return "The int is " + a;
    }

    public String f(boolean a) {
        return "The bool is " + a;
    }

    public String F(Byte a) {
        return "The byte is " + a;
    }

    public String F(String a) {
        return "The String is " + a;
    }

}
