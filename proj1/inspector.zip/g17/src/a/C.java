package a;

public class C extends B {
    boolean f;

    public int g(int h) {
        return d + h;
    }

    public String r(String a) {
        return a + ", is a string.";
    }

    public static long i = 10L;
}
