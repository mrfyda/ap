package a;

class X {

    private int dup = 1;

    public void a() {
        System.out.println("it works!");
    }

}

public class Y extends X {

    private int dup = 2;

    public C c1 = new C();

    public C c2 = null;

}
